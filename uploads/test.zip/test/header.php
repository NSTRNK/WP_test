<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package test-test
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/style.min.css" />	
	<style>
		.drop-down {
			position: relative;
		}
		.drop-down::after {
			content: '';
			position: absolute;
			width: 14px;
			height: 7px;
			background: url(<?php echo get_template_directory_uri() ?>/img/drop-down.png) no-repeat center center ;
			top: 6px;
			right: -25px;
		}
		.drop-right {
			position: relative;
		}
		.drop-right::after {
			content: '';
			position: absolute;
			width: 15px;
			height: 7px;
			transform: rotate(-90deg);
			background: url(<?php echo get_template_directory_uri() ?>/img/drop-down-white.png) no-repeat center center ;
			top: 10px;
			right: 0px;
		}
	</style>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'test' ); ?></a>

	<header id="masthead" class="site-header header double-line">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo"><img src="<?php echo get_template_directory_uri() ?>/img/logo.png" alt="" /></a>
		<nav id="site-navigation" class="main-navigation">	
			<div class="menu-wrapper">
				<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'menu_id'        => 'primary-menu',
						)
					);
					?>
			</div>
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->
