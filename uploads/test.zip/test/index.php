<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package test-test
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	if (have_posts()) :

		if (is_home() && !is_front_page()) :
	?>
			<header>
				<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
			</header>
		<?php
		endif;

		/* Start the Loop */
		while (have_posts()) :
			the_post(); ?>
			<div class="post double-line">
				<div class="separator">
					<img src="<?php echo get_template_directory_uri() ?>/img/separator.png" alt="" />
				</div>
				<div class="post-thumbnail">
					<?php echo the_post_thumbnail('full'); ?>
				</div>
				<div class="post-wrapper">
					<div class="post-data">
						<span class="date"><?php echo get_the_date('j F'); ?>,</span>
						<span class="author">by <?php the_author(); ?></span>
					</div>
					<div class="post-title"><?php the_title(); ?></div>
					<div class="post-text">
						<?php the_content(); ?>
					</div>
					<a href="<?php echo get_permalink(); ?>" class="post-link">read post</a>
				</div>
			</div>
	<?php
		endwhile;

		the_posts_pagination(array(
			'prev_text'    => __('<img src="'.$root.'/img/prev.png" alt="prev" />'),
			'next_text'    => __('<img src="'.$root.'/img/next.png" alt="next"
			/>'),
			'show_all'     => false,
			'end_size'     => 2,
			'mid_size'     => 2,
		));

	else :

		get_template_part('template-parts/content', 'none');

	endif;
	?>

</main><!-- #main -->

<?php
get_footer();
