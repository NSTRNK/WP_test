<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package test-test
 */

get_header();
?>

<main id="primary" class="site-main page-main">
	<div class="heading double-line bp">
		<h2 class="text-center">Typography</h2>
		<p>
			Sed ut perspiciatis unde omnis iste na tus error
			<span class="bold-underline">sit voluptatem</span>
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			iplo inventore veritatiset quasi architecto beatae voluptatem
			accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae
			ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h1>Heading One (44)</h1>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h2>Heading Two (34)</h2>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h3>Heading Three (24)</h3>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h4>Heading Four (20)</h4>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h5>Heading Five (17)</h5>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<h6>Heading Six (13)</h6>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
	</div>
	<div class="Blockquotes double-line bp">
		<h2>Blockquotes</h2>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto. beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<blockquote class="wp-block-quote">
			<p>
				“Sed ut perspiciatis unde omnis iste natus error sit voluptatem
				accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
				quae ab illo inventore veritatiset quasi architecto beatae!”
			</p>
			<cite>Ashley Williams</cite>
		</blockquote>
		<p>
			Sed ut perspiciatis unde omnis iste natus error sit voluptatem
			accusantium doloremque veritatem laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatiset quasi architecto. beatae
			voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque
			ipsa quae ab illo inventore veritatis” et quasi architecto beata
		</p>
		<blockquote class="blockquote-bg-green">
			<p>
				“Sed ut perspiciatis unde omnis iste natus error sit voluptatem
				accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
				quae ab illo inventore veritatiset quasi architecto beatae!”
			</p>
			<cite>Ashley Williams</cite>
		</blockquote>
	</div>
	<div class="wp-block-table bp">
		<h2>Table</h2>
		<table>
			<tbody>
				<tr>
					<td>
						<h5>Title One</h5>
					</td>
					<td>
						<h5>Title One</h5>
					</td>
					<td>
						<h5>Title One</h5>
					</td>
					<td>
						<h5>Title One</h5>
					</td>
				</tr>
				<tr>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
				</tr>
				<tr>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
				</tr>
				<tr>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
				</tr>
				<tr>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
					<td>Title Two</td>
				</tr>
			</tbody>
		</table>
	</div>

</main><!-- #main -->

<?php
get_footer();
