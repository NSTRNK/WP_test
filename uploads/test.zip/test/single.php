<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package test-test
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	while (have_posts()) :
		the_post(); ?>

		<article class="post double-line">
			<div class="separator"><img src="<?php echo get_template_directory_uri() ?>/img/separator.png" alt="" /></div>
			<div class="post-title"><?php the_title(); ?></div>
			<div class="post-thumbnail">
				<?php echo the_post_thumbnail('full'); ?>
			</div>
			<div class="post-data">
				<span class="date"><?php echo get_the_date('j F'); ?>,</span>
				<span class="author">by <?php the_author(); ?></span>
			</div>
			<div class="post-text">
				<?php the_content(); ?>
			</div>
		</article>
	<?php
		the_post_navigation(
			array(
				'prev_text' => '<div class="prev-post nav-link">
				<img src="' . $root . '/img/prev-white.png" alt="prev">
				<div class="nav-wrapper">
				  <span class="navigation-subtitle">' . esc_html__('Preview Post', 'test') . '</span>
				  <span class="navigation-title">%title</span>
				</div>
				</div>',
				'next_text' => '<div class="next-post nav-link">
				<img src="' . $root . '/img/next-white.png" alt="next">
				<div class="nav-wrapper">
				  <span class="navigation-subtitle">' . esc_html__('Next Post', 'test') . '</span>
				  <span class="navigation-title">%title</span>
				</div>
			  </div>',
			)
		);

	endwhile; // End of the loop.
	?>

</main><!-- #main -->

<?php
get_footer();
